/*  Inicializa Firebase con la
 * configuración del proyecto.
 * Revisa la configuración en tu
 * servidor de Firebase y cópiala
 * aquí sustituyendo los
 * asteriscos. Los campos deben
 * quedar igual que en tu
 * servidor. */
// @ts-ignore
firebase.initializeApp({
    apiKey: "AIzaSyCfMMR4bFjJgfECWOsx6iRCHPZTeDQ9GBQ",
    authDomain: "bdfalumnos41.firebaseapp.com",
    projectId: "bdfalumnos41",
    storageBucket: "bdfalumnos41.appspot.com",
    messagingSenderId: "463512573259",
    appId: "1:463512573259:web:2531082c01b911490b04ce",
    measurementId: "G-DXY3ZYMKY4"
});
