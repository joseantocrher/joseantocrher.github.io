export function
  muestraAlumnos() {
  location.href =
    "alumnos.html";
}

export function
  muestraUsuarios() {
  location.href = "usuarios.html";
}
